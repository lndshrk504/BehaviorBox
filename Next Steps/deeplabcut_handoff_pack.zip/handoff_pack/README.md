# README

## Project
DeepLabCut live mouse eye tracking on a Pop!_OS workstation, with local MATLAB integration over an IP port.

## Scope of this handoff
This handoff pack summarizes only facts stated in this chat. Any field that depends on user templates or information not present in the chat is marked `UNKNOWN`.

## Current objective
Get a live eye-tracking pipeline running quickly on a computer with:
- Pop!_OS
- 13th gen Intel processor
- NVIDIA RTX 4060
- FLIR Chameleon3 camera
- MATLAB running on the same machine

The preferred initial approach is to use the pre-existing DeepLabCut Model Zoo mouse pupil model `mouse_pupil_vclose` for fastest time-to-first-result.

## Agreed direction
- Use the existing `mouse_pupil_vclose` model first.
- Prefer the TensorFlow-backed DeepLabCut path for that specific pretrained model, because the prior discussion stated that the documented Model Zoo workflow for this model is TensorFlow-based.
- Use DLCLive for real-time inference.
- Acquire frames from the FLIR Chameleon3 using Spinnaker/PySpin.
- Communicate tracking output to MATLAB on the same machine via localhost UDP.
- Consider training or fine-tuning later if the pretrained model is not robust enough.

## What is already known from the chat
- Operating system: Pop!_OS
- CPU generation: 13th gen Intel
- GPU: NVIDIA 4060
- Camera: FLIR Chameleon3
- MATLAB location: same machine as the tracker
- Desired IPC: IP port output
- Proposed IPC mechanism: UDP on localhost
- Proposed real-time output: either raw keypoints or derived pupil metrics
- Proposed derived metrics: ellipse center, major axis, minor axis, angle, mean likelihood, valid flag
- Model of interest: `mouse_pupil_vclose`
- Intended software components:
  - DeepLabCut
  - DLCLive
  - TensorFlow backend for the initial pretrained-model path
  - Spinnaker SDK / PySpin for FLIR camera access
  - MATLAB UDP receiver

## What remains UNKNOWN
- Exact Pop!_OS version
- Exact NVIDIA driver version
- Exact CUDA/cuDNN versions
- Exact Spinnaker SDK version
- Exact Python version actually installed
- Exact MATLAB version
- Exact camera model suffix for the Chameleon3
- Target ROI dimensions
- Target FPS
- Final UDP port number to standardize on
- Whether the pretrained model generalizes well enough to the user's eye videos without fine-tuning

## Proposed high-level architecture
1. FLIR Chameleon3 camera streams frames through Spinnaker/PySpin.
2. Frames are converted to an array suitable for DLCLive.
3. DLCLive runs the exported DeepLabCut model in real time.
4. The 8 pupil landmarks from `mouse_pupil_vclose` are converted to a fitted ellipse when enough high-confidence points are present.
5. A compact UDP packet is sent to MATLAB over localhost.
6. MATLAB reads the packet and uses the pupil metrics online.

## Notes on training
Training is optional for the initial milestone. The prior discussion described the likely next step as active-learning-style refinement:
- analyze videos with the pretrained model
- extract outlier frames
- refine labels
- merge datasets
- retrain
- re-export for live use

## Redactions
No secrets were provided in the chat. No redactions were required beyond avoiding real user paths and credentials.

## Files in this handoff pack
- `README.md`
- `CONTEXT_MANIFEST.md`
- `docs/architecture.md`
- `docs/methods.md`
- `docs/repro.md`
- `docs/decision_log.md`
- `docs/backlog.md`
- `docs/data_dictionary.md`
