# CONTEXT_MANIFEST

## Provenance
This handoff pack was generated from a single chat conversation. It contains only facts stated in that conversation. It does not add new external facts beyond what was already discussed there.

## Template status
The user requested that `README.md` and `CONTEXT_MANIFEST.md` match their templates, but no templates were provided in the chat. Therefore, this file uses a best-effort structure and marks template-specific unknowns as `UNKNOWN`.

## Facts-only rule
- Use only facts present in the chat.
- Mark any missing information as `UNKNOWN`.
- Do not infer hidden configuration values.
- Do not fabricate file paths, versions, or performance numbers.

## Redaction policy
- Secrets: none provided
- Credentials: none provided
- Tokens/API keys: none provided
- Personal paths: redacted to placeholders where applicable

## Primary user goals
1. Verify that DeepLabCut can be used as a live eye tracker for a mouse.
2. Verify that an example existed on NVIDIA Jetson.
3. Verify that the DeepLabCut Model Zoo includes a mouse eye model.
4. Get the system running on Pop!_OS with a 13th gen Intel CPU and NVIDIA 4060 GPU.
5. Send tracking output to MATLAB over an IP port.
6. Understand what training a model would look like if needed.

## Confirmed environment from chat
- OS: Pop!_OS
- CPU: 13th gen Intel
- GPU: NVIDIA 4060
- Camera: FLIR Chameleon3
- MATLAB: same machine as tracker
- Networking intent: localhost IP communication

## Confirmed technical decisions from chat
- Initial model choice: `mouse_pupil_vclose`
- Initial backend path: TensorFlow-backed DeepLabCut workflow for that pretrained model
- Live inference path: DLCLive
- Camera SDK path: Spinnaker / PySpin
- MATLAB communication path: UDP over localhost
- Message content preference: raw keypoints or derived ellipse metrics, with derived metrics favored for simplicity

## Key technical claims already made in the chat
- A Jetson-based real-time pupil tracking example using DeepLabCut was discussed earlier in the conversation.
- The DeepLabCut Model Zoo mouse pupil model `mouse_pupil_vclose` was discussed earlier in the conversation.
- The prior discussion stated that the documented Model Zoo workflow for that model currently uses the TensorFlow engine.
- The prior discussion stated that DLCLive supports both TensorFlow and PyTorch model types, but the exported formats differ.
- The prior discussion stated that TensorFlow is not inherently better for pupil tracking; it is preferred here only because this specific pretrained model workflow was described as TensorFlow-based.

## Unknowns and gaps
- User templates for `README.md` and `CONTEXT_MANIFEST.md`
- Exact software versions across the stack
- Exact camera configuration
- Exact ROI/FPS targets
- Measured latency on the target workstation
- Confirmed zero-shot performance of the pretrained model on the user's videos

## Intended deliverable state after implementation
A working real-time pipeline on one Pop!_OS machine:
- camera capture from FLIR Chameleon3
- live inference via DLCLive
- UDP packet emission over localhost
- MATLAB receiver consuming packets online

## Non-goals explicitly or implicitly outside this handoff
- A completed installation log
- Benchmark numbers measured on the target machine
- A finished training run
- A guaranteed TensorRT path
- Any secrets or credentials
