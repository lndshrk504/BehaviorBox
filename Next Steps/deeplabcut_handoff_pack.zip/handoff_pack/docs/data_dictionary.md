# Data Dictionary

## Scope
This file describes the data objects mentioned in the chat. Any field not defined there is marked `UNKNOWN`.

## Core runtime objects

### Frame
- Name: `frame`
- Type: image array
- Source: FLIR Chameleon3 via PySpin
- Shape: `UNKNOWN`
- Dtype: expected image dtype, exact value `UNKNOWN`
- Notes: prior discussion suggested Mono8 when available; a 3-channel array may be constructed for DLCLive compatibility

### Pose
- Name: `pose`
- Type: array
- Meaning: model output for landmarks
- Shape: approximately `(K, 3)` as previously discussed
- Columns:
  1. x coordinate
  2. y coordinate
  3. likelihood
- K: 8 for the `mouse_pupil_vclose` pupil landmarks, according to the earlier discussion

## Landmark set

### Model name
- `mouse_pupil_vclose`

### Landmark semantics
The prior discussion stated the pupil model predicts 8 landmarks around the pupil boundary. The following landmark names were mentioned earlier in the conversation:
- `Lpupil`
- `LDpupil`
- `Dpupil`
- `DRpupil`
- `Rpupil`
- `RVpupil`
- `Vpupil`
- `VLpupil`

## Derived metrics

### `cx`
- Meaning: fitted ellipse center x
- Type: float
- Units: pixels, assumed from image coordinate system

### `cy`
- Meaning: fitted ellipse center y
- Type: float
- Units: pixels, assumed from image coordinate system

### `major`
- Meaning: fitted ellipse major axis
- Type: float
- Units: pixels

### `minor`
- Meaning: fitted ellipse minor axis
- Type: float
- Units: pixels

### `angle`
- Meaning: fitted ellipse rotation angle
- Type: float
- Units: degrees

### `mean_lk`
- Meaning: mean landmark likelihood for the current frame
- Type: float

### `valid`
- Meaning: whether a valid ellipse fit was produced
- Type: integer or boolean-like flag
- Expected values: 0 or 1

## Transport objects

### UDP host
- Name: `UDP_HOST`
- Value discussed: `127.0.0.1`
- Meaning: localhost because MATLAB is on the same machine

### UDP port
- Name: `UDP_PORT`
- Final standardized value: `UNKNOWN`
- Example discussed earlier: `5005`

### Packet format
The prior discussion proposed a compact binary packet for derived pupil metrics with this Python `struct` format:

`<IQ6fB`

Interpreted as:
- `I`: uint32 frame_id
- `Q`: uint64 timestamp_ns
- `6f`: six float32 values
  - cx
  - cy
  - major
  - minor
  - angle
  - mean_lk
- `B`: uint8 valid flag

### Packet size
- Derived from the above format in the earlier discussion
- Exact byte count previously discussed implicitly through the example parser
- Value: 37 bytes

## Config-like variables previously shown

### `LIKELIHOOD_THRESH`
- Meaning: per-point likelihood threshold before ellipse fitting
- Example value shown earlier: `0.8`
- Final value: `UNKNOWN`

### `MIN_POINTS_FOR_ELLIPSE`
- Meaning: minimum number of high-confidence points needed to fit an ellipse
- Example value shown earlier: `5`
- Final value: `UNKNOWN`

### `EXPORTED_MODEL_DIR`
- Meaning: path to the exported model used by DLCLive
- Value: `UNKNOWN`

## External objects

### SpinView
- Meaning: camera viewer/configuration utility in the Spinnaker SDK
- Version: `UNKNOWN`

### MATLAB receiver
- Meaning: MATLAB script that listens on UDP and parses the packet
- File path: `UNKNOWN`
- MATLAB version: `UNKNOWN`

## Datasets
No concrete dataset files were provided in the chat.

Known dataset-like assets mentioned:
- user eye videos for testing: `UNKNOWN`
- pretrained model artifact for `mouse_pupil_vclose`: external dependency, not a local dataset in this handoff
