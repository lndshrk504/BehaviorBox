# Repro

## Purpose
Capture the reproducible path that was proposed in the chat, while marking all missing values as `UNKNOWN`.

## Repro status
This is a proposed reproduction procedure from the chat. It is not a completed execution log.

## Environment summary
- OS: Pop!_OS
- CPU: 13th gen Intel
- GPU: NVIDIA 4060
- Camera: FLIR Chameleon3
- MATLAB: same machine
- Python version: `UNKNOWN`
- MATLAB version: `UNKNOWN`

## Reproduction outline

### Step 1. Install and verify camera SDK
Target components:
- Spinnaker SDK
- PySpin

Expected validation:
- camera visible in SpinView
- frames stream successfully
- pixel format and ROI can be adjusted

Exact SDK version: `UNKNOWN`

## Step 2. Prepare DeepLabCut environment
The prior discussion proposed a TensorFlow-capable DeepLabCut environment on Linux because the initial pretrained-model path is TensorFlow-based.

Previously discussed command sequence:

```bash
conda create -n deeplabcut-with-tf "python=3.10"
conda activate deeplabcut-with-tf
pip install "tensorflow==2.12" "tensorpack>=0.11" "tf_slim>=1.1.0"
pip install "torch==2.3.1" torchvision --index-url https://download.pytorch.org/whl/cu118
pushd $(dirname $(python -c 'print(__import__("tensorflow").__file__)'))
ln -svf ../nvidia/*/lib/*.so* .
popd
pip install --pre deeplabcut
```

Note:
- These commands were proposed earlier in the chat.
- Final package versions are not confirmed as installed.
- Pop!_OS compatibility with the exact sequence is assumed but not verified in this handoff.

## Step 3. Create the pretrained project
Previously discussed example pattern:

```python
import deeplabcut

config_path, train_config_path = deeplabcut.create_pretrained_project(
    "pupil",
    "you",
    [r"/path/to/your/videos_or_one_video.mp4"],
    model="mouse_pupil_vclose",
    working_directory=r"/path/to/new_project_dir",
    copy_videos=True,
    videotype=".mp4",
    analyzevideo=True,
    filtered=True,
    createlabeledvideo=True,
    trainFraction=None,
    engine=deeplabcut.Engine.TF,
)
```

Unknowns:
- actual project name
- actual working directory
- actual test video path
- whether the function signature remains unchanged in the installed version

## Step 4. Export the model for live use
Previously discussed example pattern:

```python
import deeplabcut
deeplabcut.export_model(
    cfg_path="/path/to/your_project/config.yaml",
    shuffle=1,
    TFGPUinference=True,
    overwrite=True,
    make_tar=False,
)
```

Unknowns:
- exact exported output path
- exact config path
- exact shuffle index in the created project

## Step 5. Install DLCLive
Previously discussed command:

```bash
pip install deeplabcut-live[tf]
```

## Step 6. Verify live inference on a static frame first
Before integrating the camera, verify that:
- model loads
- `init_inference` succeeds
- `get_pose` returns plausible points on a known frame

## Step 7. Integrate FLIR capture through PySpin
The prior discussion proposed:
- continuous acquisition
- newest-only buffering
- Mono8 if available
- ROI set in hardware if possible

Exact camera node settings: `UNKNOWN`

## Step 8. Compute pupil metrics
Previously discussed online metrics:
- center x
- center y
- major axis
- minor axis
- angle
- mean likelihood
- valid flag

## Step 9. Send UDP packets to MATLAB
Previously discussed example host and port:
- host: `127.0.0.1`
- port: `5005` as an example, not a finalized project requirement

## Step 10. Receive packets in MATLAB
The prior discussion proposed using MATLAB `udpport` to parse datagrams on the same machine.

## Validation checklist
- [ ] Camera visible in SpinView
- [ ] Camera visible in PySpin
- [ ] TensorFlow sees the NVIDIA GPU
- [ ] DeepLabCut project created with `mouse_pupil_vclose`
- [ ] Model export completes
- [ ] DLCLive loads exported model
- [ ] Static-frame inference looks plausible
- [ ] Live camera inference runs
- [ ] UDP packet arrives in MATLAB
- [ ] MATLAB values update online

## Known reproducibility risks
- version mismatch across TensorFlow, CUDA, driver, and DLC
- camera SDK installation friction
- frame format mismatch
- pretrained model generalization failure
