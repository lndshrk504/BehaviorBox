# Architecture

## Purpose
Describe the proposed system architecture for live mouse eye tracking with DeepLabCut and same-machine MATLAB integration.

## System summary
The proposed system is a single-machine pipeline on Pop!_OS:

`FLIR Chameleon3 -> Spinnaker/PySpin -> frame array -> DLCLive -> pupil landmarks -> ellipse fit / metrics -> UDP localhost -> MATLAB`

## Components

### 1. Camera acquisition
- Hardware: FLIR Chameleon3
- Software interface: Spinnaker SDK with PySpin
- Output: image frames suitable for Python processing

### 2. Inference engine
- Primary live inference library: DLCLive
- Initial model choice: `mouse_pupil_vclose`
- Initial backend path: TensorFlow-backed export for this pretrained model
- Alternative future path: PyTorch-trained model

### 3. Landmark interpretation
The prior discussion stated that `mouse_pupil_vclose` predicts 8 pupil landmarks around the pupil boundary.

Expected online processing:
- receive 8 keypoints with likelihood values
- threshold on likelihood
- if enough valid points are present, fit an ellipse
- derive:
  - center x
  - center y
  - major axis
  - minor axis
  - angle
  - mean likelihood
  - valid flag

### 4. Inter-process communication
- Transport: UDP
- Host: localhost / 127.0.0.1
- MATLAB runs on the same machine
- Rationale from prior discussion:
  - low latency
  - simple receiver implementation in MATLAB
  - derived metrics reduce bandwidth and parsing complexity

### 5. MATLAB consumer
- Reads UDP datagrams from localhost
- Parses either:
  - raw keypoints, or
  - derived metrics packet
- Uses the data for downstream online analysis or control

## Data flow

### Capture path
1. Camera streams frames.
2. PySpin delivers frames to Python.
3. Frames are converted to an array format compatible with DLCLive.

### Inference path
4. DLCLive runs the exported model on each frame.
5. Output is a pose array with coordinates and likelihoods.

### Metrics path
6. High-confidence pupil points are selected.
7. An ellipse is fitted when enough points pass threshold.
8. Derived metrics are packaged into a UDP datagram.

### Consumer path
9. MATLAB reads the packet.
10. MATLAB uses the packet contents online.

## Interface boundaries

### Camera -> Python
- Interface type: SDK / Python wrapper
- Concrete API: PySpin
- Version: `UNKNOWN`

### Python -> DLCLive
- Interface type: Python array handoff
- Model path type:
  - TensorFlow export directory for initial pretrained path
  - `.pt` file for a future PyTorch path

### Python -> MATLAB
- Interface type: UDP over localhost
- Port: `UNKNOWN` as a final project standard
- Example port previously discussed: 5005

## Failure modes to expect
- Camera visible in hardware but not in PySpin
- Frame format not directly matching DLCLive expectations
- GPU backend mismatch
- Pretrained model does not generalize to the actual pupil videos
- Too many low-likelihood points during blinks or glints
- MATLAB packet parser drifting from Python packet format

## Design rationale
This architecture prioritizes:
- fastest startup using a pretrained model
- minimal moving parts for MATLAB integration
- a migration path to training/fine-tuning later if needed
