# Methods

## Method objective
Get a live mouse pupil tracker working quickly, while preserving a path to improve robustness through training or fine-tuning.

## Initial method: pretrained model first
The preferred initial method from the chat is:
1. use the existing DeepLabCut Model Zoo mouse pupil model `mouse_pupil_vclose`
2. follow the TensorFlow-backed DeepLabCut workflow for that specific pretrained model
3. export the model for live use
4. run DLCLive in a real-time loop
5. send outputs to MATLAB over localhost UDP

## Why TensorFlow is used for the initial pretrained path
The prior discussion stated:
- TensorFlow is not inherently better for this task
- the reason to use TensorFlow first is that this specific pretrained model and its documented Model Zoo workflow were described as TensorFlow-based in the earlier discussion

Therefore, the TensorFlow choice is a packaging/workflow compatibility choice, not a claim that TensorFlow is intrinsically better than PyTorch for pupil tracking.

## Backend differences as discussed in the chat

### TensorFlow path
- Best fit for the immediate `mouse_pupil_vclose` pretrained-model workflow discussed earlier
- Export format for live use was described as a TensorFlow model directory used by DLCLive with `model_type="base"`

### PyTorch path
- Described in the earlier discussion as the longer-term, more future-facing direction for DeepLabCut
- Export format for live use was described as a `.pt` file used by DLCLive with `model_type="pytorch"`

### Bottom line
Framework choice here is driven by the available pretrained artifact and the documented workflow discussed earlier, not by a claim that one framework is universally superior.

## Proposed online signal processing method

### Input
A frame from the FLIR Chameleon3 camera.

### Inference output
A pose array containing:
- x coordinate
- y coordinate
- likelihood
for each predicted point

### Pupil interpretation
For `mouse_pupil_vclose`, the earlier discussion stated there are 8 pupil landmarks.

### Derived online metrics
The earlier discussion proposed computing:
- ellipse center x
- ellipse center y
- major axis
- minor axis
- ellipse angle
- mean landmark likelihood
- valid flag

### Validity logic
- threshold likelihood
- require a minimum number of confident points
- fit ellipse only when the thresholded set is sufficient
- treat low-confidence or insufficient-point frames as invalid or blink/occlusion states

## Training / fine-tuning method considered
The user asked what training would look like and indicated they would consider it.

The prior discussion described an active-learning-style loop:
1. record representative videos
2. analyze with the pretrained model
3. extract outlier frames
4. refine labels on the hard frames
5. merge datasets
6. train
7. re-export for live use

## Training rationale
Training is considered because the pretrained model may fail under:
- different lighting
- glints/reflections
- eyelid occlusions
- different optics or magnification
- different camera geometry

## Training burden
Exact frame counts were not established by the user and are therefore `UNKNOWN` as a requirement. The earlier discussion described the general idea that only a moderate number of corrected frames may be needed for a constrained setup, but this handoff does not promote any unverified numeric target beyond what was already stated informally in the chat.

## Preferred sequencing
1. get the pretrained model working first
2. validate zero-shot performance on real data
3. only then decide whether to fine-tune or retrain
