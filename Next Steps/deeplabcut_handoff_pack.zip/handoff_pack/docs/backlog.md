# Backlog

## Status legend
- `TODO` = not yet done
- `BLOCKED` = cannot complete from current chat facts alone
- `OPTIONAL` = useful but not required for the first milestone

## Immediate TODOs
1. `TODO` Install Spinnaker SDK on Pop!_OS.
2. `TODO` Install and verify PySpin.
3. `TODO` Confirm the camera streams in SpinView.
4. `TODO` Confirm the camera streams in Python through PySpin.
5. `TODO` Create the pretrained DeepLabCut project using `mouse_pupil_vclose`.
6. `TODO` Export the project for live use.
7. `TODO` Install DLCLive with the TensorFlow backend.
8. `TODO` Validate inference on a static frame.
9. `TODO` Run the live camera loop.
10. `TODO` Send UDP packets to MATLAB on localhost.
11. `TODO` Validate MATLAB packet parsing.

## Configuration tasks
1. `TODO` Choose a standard UDP port.
2. `TODO` Choose a hardware ROI on the Chameleon3.
3. `TODO` Choose exposure/gain settings.
4. `TODO` Decide whether to transmit raw keypoints or only derived metrics.
5. `TODO` Set final likelihood threshold and minimum-point count for ellipse fitting.

## Validation tasks
1. `TODO` Measure end-to-end latency.
2. `TODO` Measure achieved FPS.
3. `TODO` Evaluate robustness to blinks.
4. `TODO` Evaluate robustness to reflections/glints.
5. `TODO` Evaluate robustness to lighting changes.

## Training follow-ups
1. `OPTIONAL` Record representative eye videos for evaluation.
2. `OPTIONAL` Run the pretrained model on those videos.
3. `OPTIONAL` Extract outlier frames where the model fails.
4. `OPTIONAL` Refine labels on difficult frames.
5. `OPTIONAL` Fine-tune or retrain a task-specific model.
6. `OPTIONAL` Re-export the improved model for DLCLive.

## Blocked items
1. `BLOCKED` Match the user's exact README template because it was not provided in the chat.
2. `BLOCKED` Match the user's exact CONTEXT_MANIFEST template because it was not provided in the chat.
3. `BLOCKED` Finalize software versions because they were not confirmed as installed in the chat.
4. `BLOCKED` Finalize camera ROI/FPS because the user did not provide those targets.
5. `BLOCKED` Confirm actual zero-shot performance of `mouse_pupil_vclose` on the user's setup because no real data was shown in the chat.

## Later improvements
1. `OPTIONAL` Migrate from the initial TensorFlow-backed pretrained workflow to a PyTorch-trained model.
2. `OPTIONAL` Add packet versioning to the UDP protocol.
3. `OPTIONAL` Add heartbeat/status packets for MATLAB-side health monitoring.
4. `OPTIONAL` Add recording/logging for synchronized offline review.
