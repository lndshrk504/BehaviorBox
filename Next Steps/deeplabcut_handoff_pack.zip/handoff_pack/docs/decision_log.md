# Decision Log

## Format note
No explicit dates or timestamps were provided for individual decisions in the chat, so all decision times are marked `UNKNOWN`.

---

## Decision 1
- Date: `UNKNOWN`
- Decision: Use Pop!_OS as the target operating system.
- Basis: User stated the computer has Pop!_OS.
- Status: fixed

## Decision 2
- Date: `UNKNOWN`
- Decision: Use the pre-existing `mouse_pupil_vclose` model first.
- Basis: User explicitly said they would like to use that pre-existing model to get running very quickly.
- Status: fixed

## Decision 3
- Date: `UNKNOWN`
- Decision: Prefer the TensorFlow-backed path for the initial pretrained-model workflow.
- Basis: The prior discussion stated that the documented workflow for this specific pretrained Model Zoo entry is TensorFlow-based.
- Status: current implementation choice

## Decision 4
- Date: `UNKNOWN`
- Decision: Use DLCLive for real-time inference.
- Basis: The earlier discussion identified DLCLive as the official live SDK and proposed it as the real-time runtime.
- Status: current implementation choice

## Decision 5
- Date: `UNKNOWN`
- Decision: Use the FLIR Chameleon3 camera through Spinnaker/PySpin.
- Basis: User identified the camera as a FLIR Chameleon3, and the prior discussion proposed Spinnaker/PySpin as the Python integration path.
- Status: current implementation choice

## Decision 6
- Date: `UNKNOWN`
- Decision: Send tracking output to MATLAB on the same machine over an IP port using localhost UDP.
- Basis: User required output to a MATLAB program over an IP port and later stated MATLAB runs on the same machine. The prior discussion recommended UDP.
- Status: current implementation choice

## Decision 7
- Date: `UNKNOWN`
- Decision: Prefer derived pupil metrics over raw keypoints for initial MATLAB integration.
- Basis: The prior discussion stated this would simplify parsing and reduce bandwidth, while raw keypoints remain an option.
- Status: preferred but not mandatory

## Decision 8
- Date: `UNKNOWN`
- Decision: Consider training/fine-tuning only after testing the pretrained model.
- Basis: User said they would consider training. The prior discussion proposed starting with the pretrained model first for speed.
- Status: deferred follow-up

## Decision 9
- Date: `UNKNOWN`
- Decision: Treat missing template requirements and missing config fields as `UNKNOWN`.
- Basis: User requested a handoff pack constrained to facts in this chat only.
- Status: applied in this handoff
