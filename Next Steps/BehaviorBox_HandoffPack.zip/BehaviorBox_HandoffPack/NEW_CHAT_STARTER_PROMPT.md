NEW_CHAT_STARTER_PROMPT
> You are taking over the BehaviorBox codebase handoff. Use only facts in this handoff.  
> Goals: (1) eliminate input/graphics lag; (2) maintain/extend stall-detect stimulus blink; (3) improve maintainability by identifying dead/duplicate code safely.  
> Current status: revised “*_Revised” files exist (v4) implementing hgtransform wheel motion + object pooling (including NaN polyline collapse per chat).  
> Tasks:
> 1) Verify the revised approach against the actual original files (`BehaviorBoxVisualStimulus.m`, `BehaviorBoxWheel.m`, `BehaviorBoxSerialInput.m`, `BehaviorBoxSerialTime.m`) and reconcile any API differences.  
> 2) Benchmark wheel-loop latency and graphics FPS on i9+4060, AMD, and N150 iGPU. Provide recommended `GraphicsUpdateHz` and flash behavior settings per machine.  
> 3) Propose a serial I/O redesign: binary packet format + `serialport` byte callbacks + numeric ring buffer; optionally a MEX serial reader for minimum jitter.  
> 4) Produce a safe deprecation plan: identify unused functions via dependency analysis, move to `legacy/` first, then remove once validated by a regression test run.
