# CONTEXT_MANIFEST

## Provenance
This handoff pack is generated strictly from a single ChatGPT conversation. It contains:
- User-provided descriptions of the project and performance requirements
- A code excerpt for `readLeverLoopAnalogWheel(this)` from `BehaviorBoxWheel.m`
- Assistant-proposed refactors and revised file artifacts uploaded during the chat

## Scope of truth
Only facts explicitly present in the conversation are treated as known. Everything else is marked **UNKNOWN**.

## Core modules (as described)
- `BB_App.m`: creates the app; calls Wheel or Nose path
- `BehaviorBoxWheel.m`: wheel trials; reads Arduino programmed by `Rotary.ino`
- `BehaviorBoxNose.m`: nose/photogate trials; reads Arduino programmed by `Photogate.ino`
- `BehaviorBoxVisualStimulus.m`: visual stimulus generation/rendering
- `BehaviorBoxData.m`: live and offline behavioral score analysis
- `Timekeeper.ino`: microscope timestamp capture for syncing imaging frames to behavior

## Primary experimental measure
- Trials to reach >80% performance at each level (for WT vs autism gene carriers comparisons)

## Performance priorities
- Eliminate input lag and graphics lag
- Prefer preallocation, pooling, minimal redraw, minimal allocations in hot loops

## Machines / environments
- MATLAB version: 2025b (all systems)
- Wheel rigs:
  - Intel i9 + NVIDIA 4060
  - AMD “395+” (UNKNOWN exact model)
- Nose rig:
  - Intel N150 integrated graphics

## Conversation-derived changes delivered (high level)
- Stall detection: if wheel reading does not change for 5 seconds → call `FlashNew(...)`
- Replace implicit `toc` usage with explicit `toc(tLoop)` to avoid `tic` resets breaking timeout accounting
- Cache `Lines` handles and refresh only when invalid
- Move wheel motion from axes position updates to `hgtransform` object motion
- Introduce and extend object pooling, including NaN polyline technique (claimed in chat)

## Serial I/O discussion
- Question raised: could C++ be faster?
- Answer in chat: C++ can reduce jitter and parsing overhead, but biggest wins likely from switching MATLAB approach to:
  - binary packets
  - byte-count callbacks
  - minimal callback work
  - numeric ring buffers
- Possible MATLAB↔C++ comm options mentioned: MEX, shared memory, UDP (all conceptual, not implemented in chat)

## Uploaded / referenced artifacts (from conversation)
### Original files mentioned as uploaded into the environment (paths unknown here)
- `BB_App.m`
- `BehaviorBoxWheel.m`
- `BehaviorBoxNose.m`
- `BehaviorBoxVisualStimulus.m`
- `BehaviorBoxSerialInput.m`
- `BehaviorBoxSerialTime.m`
- `BehaviorBoxData.m`
- `viewDualCameras.m`
- Arduino:
  - `Rotary.ino`
  - `Photogate.ino`
  - `Timekeeper.ino`
  - `screen_blanking_mbo_lbm_february_2025.ino`

### Revised artifacts created during chat (explicit filenames)
- `BB_App_Revised.m`
- `BehaviorBoxWheel_Revised.m`
- `BehaviorBoxNose_Revised.m`
- `BehaviorBoxVisualStimulus_Revised.m`
- `BehaviorBoxSerialInput_Revised.m`
- `BehaviorBoxSerialTime_Revised.m`
- `BehaviorBoxData_Revised.m`
- `Rotary_Revised.ino`
- `Photogate_Revised.ino`
- `Timekeeper_Revised.ino`
- `screen_blanking_mbo_lbm_february_2025_Revised.ino`
- `viewDualCameras_Revised.m`
- Bundles:
  - `BehaviorBox_RevisedBundle.zip`
  - `BehaviorBox_RevisedBundle_PoolTransform.zip`
  - `BehaviorBox_RevisedBundle_PoolTransform_v3.zip`
  - `BehaviorBox_RevisedBundle_PoolTransform_v4.zip`
- Additional “v4” named files:
  - `BehaviorBoxVisualStimulus_Revised_v4.m`
  - `BehaviorBoxWheel_Revised_v4.m`
  - `BehaviorBoxNose_Revised_v4.m`

> IMPORTANT: This manifest does not verify the contents of these files; it records only that they were referenced/produced in the conversation.

## Redactions
- No secrets, credentials, API keys, or identifiable subject IDs were included in the chat. No redactions applied.

## UNKNOWN / Not provided
- Exact internal class structures, properties, and method signatures (beyond snippets)
- Actual git history and existing unused/dead code locations beyond assistant speculation
- Actual serial baud rates and message formats used in `.ino` files
- Exact definitions of “levels” and how performance is computed per level
