# Decision Log (conversation-derived)

> This log records decisions/changes discussed in the chat. Verify in code.

## 2026-03-03 — Stall detection in wheel loop
- Decision: If wheel value does not change for 5 seconds, flash stimulus.
- Implementation notes:
  - Use explicit timers (`tLoop`, `tStall`) rather than resetting global `tic`.
  - Flash call requested:
    - `Lines = [findobj('Tag','Contour'); findobj('Tag','Distractor')];`
    - `this.FlashNew(this.StimulusStruct, this.Box, Lines, 'Correct_Confirmation')`

## 2026-03-03 — Avoid `tic/toc` collisions
- Decision: Replace bare `toc` uses with explicit `toc(tLoop)` so stall timing does not break:
  - timeout
  - response_time
  - wheelchoicetime

## 2026-03-03 — Cache graphics handles
- Decision: Cache `Lines` handles once per trial and refresh only if invalid.

## 2026-03-03 — Object pooling
- Decision: Avoid delete/recreate per trial; pool stimulus graphics objects.
- Additional constraint noted: `FlashNew()` may force `Visible=1` on all lines; pooled-but-unused lines must be cleared (`XData/YData=NaN`) to avoid ghost appearance.

## 2026-03-03 — Move objects instead of axes
- Decision: Wheel motion should use `hgtransform` translation of stimulus objects, not `axes.Position` updates.

## 2026-03-03 — Extend pooling beyond contour/distractor
- Decision: Extend pooling beyond contour/distractor lines (details in revised v4 claim in chat).
- Claimed improvement: represent multiple segments via NaN-separated polylines to reduce object count.

## 2026-03-03 — Consider C++ for serial I/O
- Decision status: Not implemented; exploratory discussion only.
- Key takeaways:
  - C++ can reduce jitter and parsing overhead
  - But biggest wins likely from binary protocol + byte callbacks + ring buffers even within MATLAB
