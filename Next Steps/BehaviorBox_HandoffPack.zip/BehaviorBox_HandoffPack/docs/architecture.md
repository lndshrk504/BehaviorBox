# Architecture

## System overview (conversation-derived)

BehaviorBox is a MATLAB application that:
1) Displays visual stimuli to mice
2) Reads behavioral responses from an Arduino device (wheel encoder or photogates)
3) Logs behavioral and timing data
4) Computes online and offline performance metrics (notably trials-to-80% per level)
5) Optionally syncs behavior to 2-photon imaging timestamps via a dedicated Arduino timekeeper

## Major components

### MATLAB app entry
- **`BB_App.m`**
  - Creates the GUI/app
  - Chooses which task mode to run:
    - Wheel mode: `BehaviorBoxWheel.m`
    - Nose mode: `BehaviorBoxNose.m`

### Input modules
- **`BehaviorBoxWheel.m`**
  - Runs trial logic using a wheel response
  - Reads from Arduino firmware `Rotary.ino`
  - Contains the loop `readLeverLoopAnalogWheel(this)` (snippet provided in chat)
  - Added feature: detect 5-second stall (no wheel change) and flash stimulus

- **`BehaviorBoxNose.m`**
  - Runs trial logic using nose/photogate input
  - Reads from Arduino firmware `Photogate.ino`

### Stimulus rendering
- **`BehaviorBoxVisualStimulus.m`**
  - Creates stimuli shown to mice
  - Revised versions implement:
    - object pooling
    - wheel motion via `hgtransform` (object transforms)
    - (claimed) NaN-separated polylines to reduce object count

### Data analysis
- **`BehaviorBoxData.m`**
  - Functions used for live and post-hoc analysis of performance
  - Conversation mentions adding:
    - trials-to-criterion computations
    - Bayesian and survival-analysis suggestions (conceptual unless implemented)

### Imaging sync
- **`Timekeeper.ino`**
  - Captures timestamps from 2-photon scanning microscope
  - Purpose: sync recorded frames to behavioral time points

## Data flow (high-level)
Arduino sensor → serial → MATLAB serial class → trial loop updates stimulus → decision → log → live performance computation → saved session output

## Performance hot paths (as identified in chat)
- Wheel loop: frequent serial reads + graphics updates
- Flashing logic inside loops
- Graphics object creation/deletion per trial
- Axis reposition updates vs object transform updates
- String parsing (`str2double`, `readline`) and growing arrays in callbacks

## UNKNOWN
- Exact file/class boundaries and how BB_App wires objects together
- Exact internal representation of “levels” and performance computations
- Exact logging format and storage locations
