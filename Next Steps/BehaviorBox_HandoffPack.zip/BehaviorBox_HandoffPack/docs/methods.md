# Methods

## Experimental context (as stated)
- Visual neuroscience experiments in mice, including autism gene carriers.
- Primary group comparison is between wildtypes and autism gene carriers.

## Primary outcome metric
- **Trials to exceed 80% performance at each level**
  - Used to compare animals across genotypes.

## In-session computation (UNKNOWN)
- How "performance" is computed (e.g., sliding window accuracy, block-wise accuracy) is not specified in the chat.
- What defines a “level” is not specified in the chat.

## Analysis approaches suggested in chat (conceptual)
These were suggested as potential improvements:
- Treat “trials to criterion” as **time-to-event**:
  - Kaplan–Meier curves and log-rank tests
  - Cox proportional hazards (with genotype as a covariate)
  - Censoring for animals that never achieve criterion
- Bayesian criterion crossing:
  - Beta-binomial posterior probability of p > 0.8 crossing a confidence threshold
- State-space learning curve models (latent p_t with random walk on logit scale)
- Logistic regression models for bias/history effects (choice ~ side + prev reward + prev choice + level)

> NOTE: These are proposals from the conversation and may not be implemented in the actual code unless verified.

## Hardware contexts for real-time behavior
- MATLAB 2025b on:
  - Intel i9 + NVIDIA 4060 (wheel)
  - AMD “395+” (wheel) (exact model UNKNOWN)
  - Intel N150 iGPU (nose)

Implication: methods that require heavy computation in the trial loop should be avoided; prioritize minimal real-time compute and perform intensive modeling offline.
