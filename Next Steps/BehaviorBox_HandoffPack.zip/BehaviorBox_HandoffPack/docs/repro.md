# Repro / Runbook

## Goal
Provide steps to reproduce:
- Wheel experiments
- Nose experiments
- Imaging time sync logging
- Post-hoc performance computation

## What is known (from chat)
- Entry point: `BB_App.m` creates the app
- Two behavioral modes:
  - Wheel: `BehaviorBoxWheel.m` + Arduino `Rotary.ino`
  - Nose: `BehaviorBoxNose.m` + Arduino `Photogate.ino`
- Visual stimuli: `BehaviorBoxVisualStimulus.m`
- Behavioral analysis: `BehaviorBoxData.m`
- Imaging sync: `Timekeeper.ino`

## What is UNKNOWN (not provided)
- Serial port configuration (COM/tty), baud rates, terminators
- MATLAB path setup and required toolboxes
- Exact UI steps to start a session
- Output file locations and naming conventions
- Calibration values (e.g., `Setting_Struct.TurnMag`, `Box.Timeout_after_time`)
- How “levels” are configured and advanced

## Suggested reproducibility checklist (needs verification)
1) Connect Arduino(s) for wheel/nose and confirm serial connectivity.
2) Launch MATLAB 2025b and add project folder to path.
3) Run `BB_App.m` (or its app entry function/script).
4) Select mode (Wheel or Nose) and start a session.
5) Confirm stimulus display and response acquisition.
6) Validate stall-blink behavior (wheel): hold wheel constant > 5 seconds and confirm flash.
7) Save session outputs.
8) Use `BehaviorBoxData.m` to compute trials-to-80% per level.

## Performance benchmarking plan (from chat priorities)
- Measure:
  - input latency (wheel/nose to displayed motion/feedback)
  - graphics update rate
  - serial callback jitter
- Run on each target system:
  - i9+4060
  - AMD rig
  - N150 iGPU
