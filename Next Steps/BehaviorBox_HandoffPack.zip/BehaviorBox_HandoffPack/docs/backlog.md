# Backlog (prioritized for speed + maintainability)

## P0 — Validate and benchmark
- Benchmark wheel-loop latency and FPS on:
  - i9+4060
  - AMD rig
  - N150 iGPU
- Confirm stall flash behavior does not introduce lag.
- Confirm `hgtransform` motion correctness for both left/right trials.

## P0 — Serial I/O speed redesign (MATLAB-first)
- Switch Arduino→MATLAB protocol to binary packets (fixed length).
- Use `serialport.configureCallback(...,"byte",N,...)` with minimal decode.
- Store wheel as “latest value” (no strings); store timekeeper as numeric ring buffer.

## P1 — MEX / external serial reader (optional)
- Implement a MEX serial reader with background thread for lowest jitter.
- Alternative IPC: shared memory ring buffer + `memmapfile`; or UDP localhost.

## P1 — Cleanup legacy code safely
- Run dependency analysis from entry point(s) to identify unused functions.
- Move suspected dead code to `legacy/` rather than deleting.
- Add a regression run checklist for Wheel and Nose modes.

## P1 — Further graphics optimization
- Consolidate all segment-based stimuli into NaN-separated polylines wherever possible.
- Avoid any per-frame calls to `findobj`.
- Ensure axis limits are fixed (manual) to avoid autoscale costs.

## P2 — Analysis improvements (offline)
- Implement survival-analysis workflow for trials-to-80% with censoring.
- Bayesian criterion crossing for robust “learned” detection.
- Learning curve state-space model + bias/history regression.

## P2 — Documentation + tests
- Document serial protocol and message formats.
- Add timing tests for serial jitter and draw scheduling.
