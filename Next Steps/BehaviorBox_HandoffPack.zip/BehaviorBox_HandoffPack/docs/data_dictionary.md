# Data Dictionary (conversation-derived)

> This dictionary only includes variables explicitly referenced in the chat. Everything else is UNKNOWN.

## Core objects/structs
- `this` (MATLAB class instance in Wheel/Nose modules): UNKNOWN exact class
- `this.Box`
  - `Timeout_after_time`: timeout for choice loop (numeric or empty)
- `this.Setting_Struct`
  - `TurnMag`: wheel magnitude scaling factor (threshold divisor)
  - `RoundUp`: boolean flag
  - `RoundUpVal`: numeric percentage used to scale threshold
  - `OnlyCorrect`: boolean; if true, wrong responses trigger OnlyCorrect loop
- `this.StimulusStruct`: stimulus configuration struct (fields UNKNOWN)
- `this.fig`: MATLAB figure handle
- `this.RStimAx`, `this.LStimAx`: axes handles for right/left stimulus regions
- `this.a`: Arduino/serial interface object with:
  - `Reset()`: resets reading/encoder
  - `SerialRead`: returns a string line to parse (original snippet)
  - (in revised path) optional `ReadWheel()` returning numeric (claimed)

## Wheel loop variables (from snippet)
- `event`:
  - `-1` = no decision/timeout
  - `1`  = one side (interpreted via `isLeftTrial`)
  - `2`  = other side
- `delta`: normalized stimulus displacement derived from wheel reading
- `dist`: wheel reading from Arduino as numeric (parsed from string)
- `threshold`: scalar from `Setting_Struct.TurnMag`
- `StimDistance`: scalar used to scale wheel displacement (0.3 in snippet)
- `thresh`: positional threshold derived from axes position (typically 0.25)
- `timeout_value`: derived from `Box.Timeout_after_time`
- `this.isLeftTrial`: boolean; indicates which side is correct target

## Logging (from snippet)
- `this.wheelchoice{I}` and `this.wheelchoicetime{I}`: stored per-sample traces
  - Revised approach in chat changed to numeric preallocated arrays (claimed)
- `this.Time.Log(end+1,1) = "Choice made"`: string log append (performance concern)

## Stall flash (from user request)
- Condition: wheel value unchanged for 5 seconds
- Flash call:
  - `Lines = [findobj('Tag','Contour') ; findobj('Tag','Distractor')];`
  - `this.FlashNew(this.StimulusStruct, this.Box, Lines, 'Correct_Confirmation')`

## Serial classes (mentioned)
- `BehaviorBoxSerialInput`:
  - Connects to Arduino over serial; sends characters; receives text strings
  - Current implementation details: UNKNOWN (conversation says terminator callbacks + text parsing, but not shown)
- `BehaviorBoxSerialTime`:
  - Serial logging for timekeeper timestamps
  - Current implementation details: UNKNOWN (not shown)

## Imaging sync (mentioned)
- `Timekeeper.ino`: captures timestamps from a 2-photon scanning microscope to sync frames to behavior time points.
- Data format: UNKNOWN.

## Hardware/environment
- MATLAB 2025b
- i9 + NVIDIA 4060, AMD “395+”, Intel N150 iGPU

