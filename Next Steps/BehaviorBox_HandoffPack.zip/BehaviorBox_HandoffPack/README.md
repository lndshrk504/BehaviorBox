# BehaviorBox — Handoff Pack (Conversation-Derived)

## What this repo/project is
BehaviorBox is a MATLAB (2025b) application used for visual neuroscience behavior experiments with mice (including autism gene carriers). The program presents visual stimuli and reads behavioral responses from Arduino-connected sensors:
- **Wheel** input via `BehaviorBoxWheel.m` with Arduino firmware `Rotary.ino`
- **Nose/photogate** input via `BehaviorBoxNose.m` with Arduino firmware `Photogate.ino`

A separate Arduino firmware `Timekeeper.ino` captures timestamps from a 2-photon scanning microscope for synchronizing imaging frames with behavior timestamps.

## Primary behavioral metric
The user’s primary comparison variable is:
- **Trials required to exceed 80% performance at each level**
used to compare **wildtypes** vs **autism gene carriers**.

## Key feature request implemented (wheel stall → stimulus flash)
Requirement:
- If the Arduino wheel value **does not change for 5 seconds**, flash/blink the stimulus.

Requested flash call:
```matlab
Lines = [findobj('Tag', 'Contour') ; findobj('Tag', 'Distractor')];
this.FlashNew(this.StimulusStruct, this.Box, Lines, 'Correct_Confirmation')
```

## Performance goal
Execution speed is the top priority. The user cannot tolerate input lag or graphics lag.

## Changes delivered in revised code (per conversation)
Revised files were produced with performance refactors including:
- **Explicit timing handles** (`tLoop`, `tStall`) to avoid `tic/toc` collisions in loops
- **Object pooling** for visual stimulus graphics objects
- **Wheel motion via object transforms** (`hgtransform`) rather than moving axes positions
- **Flash optimizations**, including a non-blocking blink used for stall feedback
- Further pooling extension beyond contour/distractor, and claim of collapsing many segments into a few polylines using NaN separators (v4)

> NOTE: This README is derived only from the chat. Exact implementation details and completeness must be verified against the actual file contents.

## Target runtime environments
All systems run MATLAB 2025b.
- Wheel rigs:
  - Intel i9 + NVIDIA 4060
  - AMD “395+” system (exact model UNKNOWN)
- Nose rig:
  - Intel N150 with integrated graphics only

## Artifacts referenced/produced in this conversation
Revised files/bundles were created and uploaded during the chat (see CONTEXT_MANIFEST.md for inventory).

## Open questions / UNKNOWN
- Exact structure of the original codebase beyond file names and snippets shown
- Whether `BehaviorBoxDataNew.m` exists (user referenced it; only `BehaviorBoxData.m` is present in the uploads list)
- Exact Arduino serial protocol formats, baud rates, and parsing rules in original `.ino` files (beyond general descriptions)

## Safety & compliance
No secrets/credentials were provided in the chat. No identifying mouse subject information was shared here.
